﻿using ABCRETAIL.Models;
using ABCRETAIL.Services.Storage;

namespace ABCRETAIL.Services
{
    public class ProductService
    {
        private readonly TableStorageService<ProductEntity> _table;

        public ProductService(TableStorageService<ProductEntity> table) => _table = table;

        public Task<List<ProductEntity>> GetAllAsync() => _table.GetAllAsync();

        public Task<ProductEntity?> GetByIdAsync(string id) => _table.TryGetAsync("PRODUCT", id);

        public async Task AddAsync(ProductEntity entity)
        {
            entity.PartitionKey = "PRODUCT";
            if (string.IsNullOrWhiteSpace(entity.RowKey))
                entity.RowKey = Guid.NewGuid().ToString();

            await _table.AddAsync(entity);
        }

        public async Task UpdateAsync(ProductEntity entity)
        {
            entity.PartitionKey = "PRODUCT";
            await _table.UpdateAsync(entity);
        }

        public Task DeleteAsync(string id) => _table.DeleteAsync("PRODUCT", id);
    }
}