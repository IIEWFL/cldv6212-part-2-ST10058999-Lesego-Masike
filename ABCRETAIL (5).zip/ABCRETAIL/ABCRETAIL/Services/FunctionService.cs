﻿using ABCRETAIL.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ABCRETAIL.Services
{
    public class FunctionsService
    {
        private readonly HttpClient _httpClient;
        private readonly string _functionAppBaseUrl;
        private readonly ILogger<FunctionsService> _logger;

        public FunctionsService(IHttpClientFactory httpClientFactory, IConfiguration configuration, ILogger<FunctionsService> logger)
        {
            _httpClient = httpClientFactory.CreateClient();
            _functionAppBaseUrl = configuration["FunctionAppBaseUrl"] ?? "http://localhost:7071/api";
            _logger = logger;
        }

        // Customer Operations (mapping to CustomerDto)
        public async Task<CustomerDto> CreateCustomerAsync(CustomerEntity customer)
        {
            try
            {
                var dto = new CustomerDto
                {
                    Name = customer.Name,
                    Email = customer.Email
                };
                var content = new StringContent(JsonSerializer.Serialize(dto), Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_functionAppBaseUrl}/customers", content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<CustomerDto>(responseContent) ?? new CustomerDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating customer");
                throw;
            }
        }

        public async Task<CustomerDto> GetCustomerAsync(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_functionAppBaseUrl}/customers/{partitionKey}/{rowKey}");
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<CustomerDto>(responseContent) ?? new CustomerDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        public async Task<CustomerDto> UpdateCustomerAsync(string partitionKey, string rowKey, CustomerEntity customer)
        {
            try
            {
                var dto = new CustomerDto
                {
                    Name = customer.Name,
                    Email = customer.Email
                };
                var content = new StringContent(JsonSerializer.Serialize(dto), Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"{_functionAppBaseUrl}/customers/{partitionKey}/{rowKey}", content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<CustomerDto>(responseContent) ?? new CustomerDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        public async Task DeleteCustomerAsync(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{_functionAppBaseUrl}/customers/{partitionKey}/{rowKey}");
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        // Product Operations (mapping to ProductDto)
        public async Task<ProductDto> CreateProductAsync(ProductEntity product)
        {
            try
            {
                var dto = new ProductDto
                {
                    Name = product.Name,
                    Price = product.Price,
                    Description = product.Description
                };
                var content = new StringContent(JsonSerializer.Serialize(dto), Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_functionAppBaseUrl}/products", content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<ProductDto>(responseContent) ?? new ProductDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating product");
                throw;
            }
        }

        public async Task<ProductDto> GetProductAsync(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_functionAppBaseUrl}/products/{partitionKey}/{rowKey}");
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<ProductDto>(responseContent) ?? new ProductDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving product with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        public async Task<ProductDto> UpdateProductAsync(string partitionKey, string rowKey, ProductEntity product)
        {
            try
            {
                var dto = new ProductDto
                {
                    Name = product.Name,
                    Price = product.Price,
                    Description = product.Description
                };
                var content = new StringContent(JsonSerializer.Serialize(dto), Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"{_functionAppBaseUrl}/products/{partitionKey}/{rowKey}", content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<ProductDto>(responseContent) ?? new ProductDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating product with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        public async Task DeleteProductAsync(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{_functionAppBaseUrl}/products/{partitionKey}/{rowKey}");
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting product with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        // Order Operations (mapping to OrderDto)
        public async Task<OrderDto> CreateOrderAsync(OrderEntity order)
        {
            try
            {
                var dto = new OrderDto
                {
                    CustomerId = order.CustomerId,
                    ProductId = order.ProductId,
                    Quantity = order.Quantity
                };
                var content = new StringContent(JsonSerializer.Serialize(dto), Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_functionAppBaseUrl}/orders", content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<OrderDto>(responseContent) ?? new OrderDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating order");
                throw;
            }
        }

        public async Task<OrderDto> GetOrderAsync(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_functionAppBaseUrl}/orders/{partitionKey}/{rowKey}");
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<OrderDto>(responseContent) ?? new OrderDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving order with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        public async Task<OrderDto> UpdateOrderAsync(string partitionKey, string rowKey, OrderEntity order)
        {
            try
            {
                var dto = new OrderDto
                {
                    CustomerId = order.CustomerId,
                    ProductId = order.ProductId,
                    Quantity = order.Quantity
                };
                var content = new StringContent(JsonSerializer.Serialize(dto), Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"{_functionAppBaseUrl}/orders/{partitionKey}/{rowKey}", content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<OrderDto>(responseContent) ?? new OrderDto();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating order with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        public async Task DeleteOrderAsync(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{_functionAppBaseUrl}/orders/{partitionKey}/{rowKey}");
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting order with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                throw;
            }
        }

        // Log Operations (using AuditLogEntity)
        public async Task<string> UploadLogAsync(AuditLogEntity logRequest)
        {
            try
            {
                var content = new StringContent(JsonSerializer.Serialize(logRequest), Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_functionAppBaseUrl}/logs", content);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error uploading log");
                throw;
            }
        }

        public async Task<IEnumerable<AuditLogEntity>> GetLogsAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_functionAppBaseUrl}/logs");
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<IEnumerable<AuditLogEntity>>(responseContent) ?? new List<AuditLogEntity>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving logs");
                throw;
            }
        }
    }
}