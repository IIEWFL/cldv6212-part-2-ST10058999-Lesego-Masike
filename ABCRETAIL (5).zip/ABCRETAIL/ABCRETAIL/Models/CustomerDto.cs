﻿#nullable enable
namespace ABCRETAIL.Models
{
    public class CustomerDto
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
    }
}