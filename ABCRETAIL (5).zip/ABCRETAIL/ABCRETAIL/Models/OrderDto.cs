﻿#nullable enable
namespace ABCRETAIL.Models
{
    public class OrderDto
    {
        public string? CustomerId { get; set; }
        public string? ProductId { get; set; }
        public string? Quantity { get; set; }
    }
}