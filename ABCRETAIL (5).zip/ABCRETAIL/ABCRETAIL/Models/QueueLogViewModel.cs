﻿#nullable enable
using System;

namespace smsFunction.Models
{
    public class QueueLogViewModel
    {
        public string? MessageId { get; set; }
        public DateTimeOffset? InsertionTime { get; set; }
        public string? MessageText { get; set; }
    }
}