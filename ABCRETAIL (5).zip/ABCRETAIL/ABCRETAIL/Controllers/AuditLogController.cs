﻿using ABCRETAIL.Models;
using ABCRETAIL.Services;
using ABCRETAIL.Services.Storage;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using Azure.Data.Tables;

namespace ABCRETAIL.Controllers
{
    public class AuditLogController : Controller
    {
        private readonly QueueStorageService _queueStorageService;
        private readonly FileShareStorageService _fileShareStorageService;
        private readonly TableStorageService<AuditLogEntity> _tableStorageService;
        private readonly BlobStorageService _blobStorageService;

        public AuditLogController(QueueStorageService queueStorageService, FileShareStorageService fileShareStorageService,
            TableStorageService<AuditLogEntity> tableStorageService, BlobStorageService blobStorageService)
        {
            _queueStorageService = queueStorageService;
            _fileShareStorageService = fileShareStorageService;
            _tableStorageService = tableStorageService;
            _blobStorageService = blobStorageService;
        }

        public async Task<IActionResult> StoreToAzureTable(string logData)
        {
            var auditLog = new AuditLogEntity
            {
                PartitionKey = "AUDIT",
                RowKey = Guid.NewGuid().ToString(),
                LogData = logData
            };
            await _tableStorageService.AddAsync(auditLog);
            return Json(new { message = "Data stored in Azure Table", screenshot = "Include screenshot of table data" });
        }

        public async Task<IActionResult> WriteToAzureBlob(string logData)
        {
            var blobName = $"auditlog_{Guid.NewGuid()}.txt";
            using var stream = new MemoryStream(Encoding.UTF8.GetBytes(logData));
            await _blobStorageService.UploadPhotoAsync(blobName, stream);
            return Json(new { message = "Data written to Azure Blob", screenshot = "Include screenshot of blob storage" });
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var messages = await _queueStorageService.GetMessagesAsync();
                var logs = messages.Select(m =>
                {
                    var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(m.MessageText));
                    using var doc = JsonDocument.Parse(decoded);
                    var root = doc.RootElement;

                    var entity = "Entity";
                    if (root.TryGetProperty("Details", out var d) && d.ValueKind == JsonValueKind.Object)
                    {
                        if (d.TryGetProperty("StudentNumber", out _)) entity = "Student";
                        else if (d.TryGetProperty("Name", out _)) entity = "Customer/Product/Order";
                    }

                    return new AuditLog
                    {
                        MessageId = m.MessageId,
                        QueueInsertionTime = m.InsertedOn,
                        EventTimestamp = root.TryGetProperty("Timestamp", out var ts) ? ts.GetDateTime() : null,
                        Action = root.TryGetProperty("Action", out var a) ? a.GetString() ?? string.Empty : string.Empty,
                        Entity = entity,
                        EntityId = root.TryGetProperty("Details", out var dd) && dd.TryGetProperty("RowKey", out var rk) ? rk.GetString() : null
                    };
                }).ToList();

                return View(logs);
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Failed to load audit logs: {ex.Message}";
                return View(Enumerable.Empty<AuditLog>());
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Export()
        {
            try
            {
                var bytes = await BuildCsvAsync();
                var filename = $"AuditLog_{DateTime.UtcNow:yyyyMMddHHmmss}.csv";

                using (var uploadStream = new MemoryStream(bytes))
                {
                    await _fileShareStorageService.UploadFileAsync(filename, uploadStream);
                }

                return Json(new { message = "File sent to Azure File Share", screenshot = "Include screenshot of file in Azure Files" });
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"CSV export failed: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewCsv()
        {
            try
            {
                var bytes = await BuildCsvAsync();
                Response.Headers["Content-Disposition"] = "inline; filename=AuditLog.csv";
                return File(bytes, "text/csv");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"CSV view failed: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        private async Task<byte[]> BuildCsvAsync()
        {
            var messages = await _queueStorageService.GetMessagesAsync();

            using var ms = new MemoryStream();
            using var writer = new StreamWriter(ms, Encoding.UTF8, 1024, leaveOpen: true);

            await writer.WriteLineAsync("MessageId,QueueInsertionTime,EventTimestamp,Action,Entity,EntityId");

            foreach (var m in messages)
            {
                var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(m.MessageText));
                using var doc = JsonDocument.Parse(decoded);
                var root = doc.RootElement;

                var eventTimestamp = root.TryGetProperty("Timestamp", out var ts)
                    ? ts.GetDateTime().ToString("yyyy/MM/dd HH:mm:ss")
                    : "";

                var action = root.TryGetProperty("Action", out var a) ? a.GetString() ?? "" : "";

                var entity = "Entity";
                string? entityId = null;

                if (root.TryGetProperty("Details", out var d) && d.ValueKind == JsonValueKind.Object)
                {
                    if (d.TryGetProperty("StudentNumber", out _)) entity = "Student";
                    else if (d.TryGetProperty("Name", out _)) entity = "Customer/Product/Order";

                    if (d.TryGetProperty("RowKey", out var rk)) entityId = rk.GetString();
                }

                await writer.WriteLineAsync(
                    $"\"{m.MessageId}\",\"{m.InsertedOn:yyyy/MM/dd HH:mm:ss}\",\"{eventTimestamp}\",\"{action}\",\"{entity}\",\"{entityId}\"");
            }

            await writer.FlushAsync();
            ms.Position = 0;
            return ms.ToArray();
        }

        public async Task<IActionResult> ProcessAzureQueue(string message)
        {
            await _queueStorageService.SendMessagesAsync(new { Action = "Log", Details = new { RowKey = Guid.NewGuid().ToString() }, Timestamp = DateTime.UtcNow });
            var messages = await _queueStorageService.GetMessagesAsync();
            return Json(new { message = messages[0].MessageText, screenshot = "Include screenshot of queue message" });
        }

        // Discussion of the 2 services (Azure Blob and Azure Queue as an example)
        // - Heading: Overview of Services
        // Azure Blob Storage offers scalable storage for unstructured data like audit logs, enhancing data persistence.
        // - Mechanism
        // The WriteToAzureBlob function uploads log data using BlobStorageService, ensuring secure and efficient storage.
        // - How it adds value to end users
        // Users gain reliable access to historical data, improving audit tracking and compliance.
    }
}