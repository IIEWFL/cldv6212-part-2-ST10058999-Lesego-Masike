﻿using ABCRETAIL.Models;
using ABCRETAIL.Services;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace ABCRETAIL.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductService _productService;
        private readonly BlobStorageService _blobStorageService;

        public ProductController(ProductService productService, BlobStorageService blobStorageService)
        {
            _productService = productService;
            _blobStorageService = blobStorageService;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _productService.GetAllAsync();
            return View(products);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductEntity product, IFormFile imageFile)
        {
            if (product.Price <= 0)
                ModelState.AddModelError(nameof(ProductEntity.Price), "Price must be greater than 0.");

            if (!ModelState.IsValid)
                return View(product);

            if (imageFile?.Length > 0)
            {
                var url = await _blobStorageService.UploadPhotoAsync(
                    $"{Guid.NewGuid()}{Path.GetExtension(imageFile.FileName)}",
                    imageFile.OpenReadStream());
                product.ImageUrl = url;
            }

            await _productService.AddAsync(product);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(string id)
        {
            var product = await _productService.GetByIdAsync(id);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductEntity product, IFormFile imageFile)
        {
            if (product.Price <= 0)
                ModelState.AddModelError(nameof(ProductEntity.Price), "Price must be greater than 0.");

            if (!ModelState.IsValid)
                return View(product);

            if (imageFile?.Length > 0)
            {
                var url = await _blobStorageService.UploadPhotoAsync(
                    $"{Guid.NewGuid()}{Path.GetExtension(imageFile.FileName)}",
                    imageFile.OpenReadStream());
                product.ImageUrl = url;
            }

            await _productService.UpdateAsync(product);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Details(string id)
        {
            var product = await _productService.GetByIdAsync(id);
            if (product == null) return NotFound();
            return View(product);
        }

        public async Task<IActionResult> Delete(string id)
        {
            var product = await _productService.GetByIdAsync(id);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _productService.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}