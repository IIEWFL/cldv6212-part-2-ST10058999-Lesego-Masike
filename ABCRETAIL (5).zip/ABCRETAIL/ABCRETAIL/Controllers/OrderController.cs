﻿using ABCRETAIL.Models;
using ABCRETAIL.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ABCRETAIL.Controllers
{
    public class OrderController : Controller
    {
        private readonly OrderService _orderService;
        private readonly CustomerService _customerService;
        private readonly ProductService _productService;

        public OrderController(OrderService orderService, CustomerService customerService, ProductService productService)
        {
            _orderService = orderService;
            _customerService = customerService;
            _productService = productService;
        }

        public async Task<IActionResult> Index()
        {
            var orders = await _orderService.GetAllAsync();
            return View(orders);
        }

        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return BadRequest();

            var order = await _orderService.GetByIdAsync(id);
            if (order == null) return NotFound();

            return View(order);
        }

        public async Task<IActionResult> Create()
        {
            await LoadDropdownsAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OrderEntity order)
        {
            if (ModelState.IsValid)
            {
                await _orderService.AddAsync(order);
                return RedirectToAction(nameof(Index));
            }

            await LoadDropdownsAsync();
            return View(order);
        }

        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id)) return BadRequest();

            var order = await _orderService.GetByIdAsync(id);
            if (order == null) return NotFound();

            await LoadDropdownsAsync();
            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(OrderEntity order)
        {
            if (ModelState.IsValid)
            {
                await _orderService.UpdateAsync(order);
                return RedirectToAction(nameof(Index));
            }

            await LoadDropdownsAsync();
            return View(order);
        }

        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id)) return BadRequest();

            var order = await _orderService.GetByIdAsync(id);
            if (order == null) return NotFound();

            return View(order);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _orderService.DeleteAsync(id);
            }
            return RedirectToAction(nameof(Index));
        }

        private async Task LoadDropdownsAsync()
        {
            var customers = await _customerService.GetAllAsync();
            var products = await _productService.GetAllAsync();

            ViewBag.Customers = new SelectList(customers, "RowKey", "CustomerName");
            ViewBag.Products = new SelectList(products, "RowKey", "Name");
        }
    }
}