﻿#nullable enable
using Azure;
using System;

namespace smsFunction.Models
{
    public class OrderDto
    {
        public string? PartitionKey { get; set; }
        public string? RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public string? ETag { get; set; }

        public string? CustomerId { get; set; }
        public string? ProductId { get; set; }
        public string? Quantity { get; set; }
    }
}