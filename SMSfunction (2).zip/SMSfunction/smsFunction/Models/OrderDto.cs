﻿#nullable enable
using Azure;
using System;

namespace smsFunction.Models
{
    public class CustomerDto
    {
        public string? PartitionKey { get; set; }
        public string? RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public string? ETag { get; set; }

        public string? Name { get; set; }
        public string? Email { get; set; }
    }
}