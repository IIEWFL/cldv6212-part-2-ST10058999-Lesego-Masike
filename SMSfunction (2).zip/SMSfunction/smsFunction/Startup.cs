﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

[assembly: FunctionsStartup(typeof(smsFunction.Startup))]

namespace smsFunction
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddSingleton(sp =>
            {
                var configuration = sp.GetRequiredService<IConfiguration>();
                var connectionString = configuration["AzureWebJobsStorage"];
                var tableName = configuration["TableStorageName"];
                var logger = sp.GetRequiredService<ILogger<TableStorageService>>();
                return new TableStorageService(connectionString, tableName, logger);
            });

            builder.Services.AddSingleton(sp =>
            {
                var configuration = sp.GetRequiredService<IConfiguration>();
                var connectionString = configuration["AzureWebJobsStorage"];
                var containerName = configuration["BlobContainerName"];
                var logger = sp.GetRequiredService<ILogger<BlobStorageService>>();
                return new BlobStorageService(connectionString, containerName, logger);
            });

            builder.Services.AddSingleton(sp =>
            {
                var configuration = sp.GetRequiredService<IConfiguration>();
                var connectionString = configuration["AzureWebJobsStorage"];
                var queueName = configuration["QueueName"];
                var logger = sp.GetRequiredService<ILogger<QueueStorageService>>();
                return new QueueStorageService(connectionString, queueName, logger);
            });

            builder.Services.AddSingleton(sp =>
            {
                var configuration = sp.GetRequiredService<IConfiguration>();
                var connectionString = configuration["AzureWebJobsStorage"];
                var shareName = configuration["FileShareName"];
                var logger = sp.GetRequiredService<ILogger<FileShareStorageService>>();
                return new FileShareStorageService(connectionString, shareName, logger);
            });
        }
    }
}