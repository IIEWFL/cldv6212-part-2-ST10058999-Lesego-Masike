﻿#nullable enable
using Azure;
using Azure.Data.Tables;
using smsFunction.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace smsFunction.Services
{
    public class TableStorageService
    {
        private readonly TableClient _tableClient;

        public TableStorageService(string storageConnectionString, string tableName, Microsoft.Extensions.Logging.ILogger<TableStorageService> logger)
        {
            var serviceClient = new TableServiceClient(storageConnectionString);
            _tableClient = serviceClient.GetTableClient(tableName);
            _tableClient.CreateIfNotExists();
        }

        //Get all students Index.cshtml
        public async Task<List<Student>> GetStudentsAsync()
        {
            var students = new List<Student>();
            await foreach (var student in _tableClient.QueryAsync<Student>())
            {
                students.Add(student);
            }
            return students;
        }

        //Get student by rowkey Details.cshtml
        public async Task<Student?> GetStudentAsync(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _tableClient.GetEntityAsync<Student>(partitionKey, rowKey);
                return response.Value;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return null;
            }
        }

        //Add student Create.cshtml
        public async Task AddStudentAsync(Student student)
        {
            if (string.IsNullOrEmpty(student.PartitionKey))
            {
                throw new ArgumentNullException(nameof(student.PartitionKey), "Partition key cannot be null or empty");
            }

            if (string.IsNullOrEmpty(student.RowKey))
            {
                student.RowKey = Guid.NewGuid().ToString();
            }

            //add the student
            await _tableClient.AddEntityAsync(student);
        }

        //Edit student Edit.cshtml
        public async Task UpdateStudentAsync(Student student)
        {
            await _tableClient.UpdateEntityAsync(student, ETag.All, TableUpdateMode.Replace);
        }

        //Delete student Delete.cshtml
        public async Task DeleteStudentAsync(string partitionKey, string rowKey)
        {
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
    }
}
