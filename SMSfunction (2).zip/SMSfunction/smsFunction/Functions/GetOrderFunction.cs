using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class GetOrderFunction
    {
        private readonly TableStorageService _tableStorageService;

        public GetOrderFunction(TableStorageService tableStorageService)
        {
            _tableStorageService = tableStorageService;
        }

        [FunctionName("GetOrder")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "orders/{partitionKey}/{rowKey}")] HttpRequest req,
            string partitionKey, string rowKey,
            ILogger log)
        {
            log.LogInformation($"Processing request to get order with PartitionKey: {partitionKey}, RowKey: {rowKey}");

            try
            {
                var entity = await _tableStorageService.GetEntityAsync(partitionKey, rowKey);
                if (entity == null)
                {
                    log.LogWarning($"Order not found with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                    return new NotFoundResult();
                }

                return new OkObjectResult(entity);
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"Error retrieving order with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}