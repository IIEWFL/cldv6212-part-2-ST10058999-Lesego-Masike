﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class CreateOrderFunction
    {
        private readonly TableStorageService _tableStorageService;
        private readonly QueueStorageService _queueStorageService;

        public CreateOrderFunction(TableStorageService tableStorageService, QueueStorageService queueStorageService)
        {
            _tableStorageService = tableStorageService;
            _queueStorageService = queueStorageService;
        }

        [FunctionName("CreateOrder")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "orders")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Processing request to create a new order");

            try
            {
                var form = await req.ReadFormAsync();
                var partitionKey = "Order";
                var rowKey = Guid.NewGuid().ToString();
                var order = new { PartitionKey = partitionKey, RowKey = rowKey, CustomerId = form["customerId"], ProductId = form["productId"], Quantity = form["quantity"] };

                if (string.IsNullOrEmpty(order.CustomerId) || string.IsNullOrEmpty(order.ProductId) || string.IsNullOrEmpty(order.Quantity))
                {
                    log.LogWarning("Missing required order fields");
                    return new BadRequestObjectResult("CustomerId, ProductId, and Quantity are required");
                }

                await _tableStorageService.AddEntityAsync(order);
                await _queueStorageService.SendMessagesAsync(new { Action = "Create", Entity = order });
                log.LogInformation($"Created order with PartitionKey: {partitionKey}, RowKey: {rowKey}");

                return new OkObjectResult(order);
            }
            catch (Exception ex)
            {
                log.LogError(ex, "Error creating order");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}