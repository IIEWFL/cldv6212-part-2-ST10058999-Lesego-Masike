﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class UpdateOrderFunction
    {
        private readonly TableStorageService _tableStorageService;
        private readonly QueueStorageService _queueStorageService;

        public UpdateOrderFunction(TableStorageService tableStorageService, QueueStorageService queueStorageService)
        {
            _tableStorageService = tableStorageService;
            _queueStorageService = queueStorageService;
        }

        [FunctionName("UpdateOrder")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "put", Route = "orders/{partitionKey}/{rowKey}")] HttpRequest req,
            string partitionKey, string rowKey,
            ILogger log)
        {
            log.LogInformation($"Processing request to update order with PartitionKey: {partitionKey}, RowKey: {rowKey}");

            try
            {
                var entity = await _tableStorageService.GetEntityAsync(partitionKey, rowKey);
                if (entity == null)
                {
                    log.LogWarning($"Order not found with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                    return new NotFoundResult();
                }

                var form = await req.ReadFormAsync();
                if (form.ContainsKey("customerId")) entity.customerId = form["customerId"];
                if (form.ContainsKey("productId")) entity.productId = form["productId"];
                if (form.ContainsKey("quantity")) entity.quantity = form["quantity"];

                await _tableStorageService.UpdateEntityAsync(entity);
                await _queueStorageService.SendMessagesAsync(new { Action = "Update", Entity = entity });
                log.LogInformation($"Updated order with PartitionKey: {partitionKey}, RowKey: {rowKey}");

                return new OkObjectResult(entity);
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"Error updating order with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}