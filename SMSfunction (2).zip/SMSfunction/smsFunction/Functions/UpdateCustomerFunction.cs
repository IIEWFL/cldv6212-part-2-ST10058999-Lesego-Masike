using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class UpdateCustomerFunction
    {
        private readonly TableStorageService _tableStorageService;
        private readonly QueueStorageService _queueStorageService;

        public UpdateCustomerFunction(TableStorageService tableStorageService, QueueStorageService queueStorageService)
        {
            _tableStorageService = tableStorageService;
            _queueStorageService = queueStorageService;
        }

        [FunctionName("UpdateCustomer")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "put", Route = "customers/{partitionKey}/{rowKey}")] HttpRequest req,
            string partitionKey, string rowKey,
            ILogger log)
        {
            log.LogInformation($"Processing request to update customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");

            try
            {
                var entity = await _tableStorageService.GetEntityAsync(partitionKey, rowKey);
                if (entity == null)
                {
                    log.LogWarning($"Customer not found with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                    return new NotFoundResult();
                }

                var form = await req.ReadFormAsync();
                if (form.ContainsKey("name")) entity.name = form["name"];
                if (form.ContainsKey("email")) entity.email = form["email"];

                await _tableStorageService.UpdateEntityAsync(entity);
                await _queueStorageService.SendMessagesAsync(new { Action = "Update", Entity = entity });
                log.LogInformation($"Updated customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");

                return new OkObjectResult(entity);
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"Error updating customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}