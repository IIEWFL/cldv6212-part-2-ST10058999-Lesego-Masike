using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class CreateCustomerFunction
    {
        private readonly TableStorageService _tableStorageService;
        private readonly QueueStorageService _queueStorageService;

        public CreateCustomerFunction(TableStorageService tableStorageService, QueueStorageService queueStorageService)
        {
            _tableStorageService = tableStorageService;
            _queueStorageService = queueStorageService;
        }

        [FunctionName("CreateCustomer")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "customers")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Processing request to create a new customer");

            try
            {
                var form = await req.ReadFormAsync();
                var partitionKey = "Customer";
                var rowKey = Guid.NewGuid().ToString();
                var customer = new { PartitionKey = partitionKey, RowKey = rowKey, Name = form["name"], Email = form["email"] };

                if (string.IsNullOrEmpty(customer.Name) || string.IsNullOrEmpty(customer.Email))
                {
                    log.LogWarning("Missing required customer fields");
                    return new BadRequestObjectResult("Name and Email are required");
                }

                await _tableStorageService.AddEntityAsync(customer);
                await _queueStorageService.SendMessagesAsync(new { Action = "Create", Entity = customer });
                log.LogInformation($"Created customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");

                return new OkObjectResult(customer);
            }
            catch (Exception ex)
            {
                log.LogError(ex, "Error creating customer");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}