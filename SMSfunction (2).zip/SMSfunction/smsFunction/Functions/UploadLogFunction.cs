using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using smsFunction.Services;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace smsFunction.Functions
{
    public class UploadLogFunction
    {
        private readonly FileShareStorageService _fileShareStorageService;
        private readonly QueueStorageService _queueStorageService;

        public UploadLogFunction(FileShareStorageService fileShareStorageService, QueueStorageService queueStorageService)
        {
            _fileShareStorageService = fileShareStorageService;
            _queueStorageService = queueStorageService;
        }

        [FunctionName("UploadLog")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "logs")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Processing request to upload log file");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                dynamic data = JsonConvert.DeserializeObject(requestBody);
                string? fileName = data?.name;

                if (string.IsNullOrEmpty(fileName))
                {
                    log.LogWarning("Missing file name in request body");
                    return new BadRequestObjectResult("Please provide a file name in the request body");
                }

                var logMessages = await _queueStorageService.GetMessagesAsync();
                var content = new StringBuilder();
                content.AppendLine("MessageId,InsertionTime,MessageText");
                foreach (var msg in logMessages)
                {
                    var msgText = msg.MessageText?.Replace("\"", "\"\"");
                    content.AppendLine($"{msg.MessageId},{msg.InsertionTime},\"{msgText}\"");
                }

                using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content.ToString()));
                await _fileShareStorageService.UploadFileAsync(fileName, stream);
                await _queueStorageService.ClearMessagesAsync();

                log.LogInformation($"Uploaded log file: {fileName}");
                return new OkObjectResult($"Log file {fileName} uploaded successfully");
            }
            catch (Exception ex)
            {
                log.LogError(ex, "Error uploading log file");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}