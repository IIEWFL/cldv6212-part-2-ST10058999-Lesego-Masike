﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class GetCustomerFunction
    {
        private readonly TableStorageService _tableStorageService;

        public GetCustomerFunction(TableStorageService tableStorageService)
        {
            _tableStorageService = tableStorageService;
        }

        [FunctionName("GetCustomer")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "customers/{partitionKey}/{rowKey}")] HttpRequest req,
            string partitionKey, string rowKey,
            ILogger log)
        {
            log.LogInformation($"Processing request to get customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");

            try
            {
                var entity = await _tableStorageService.GetEntityAsync(partitionKey, rowKey);
                if (entity == null)
                {
                    log.LogWarning($"Customer not found with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                    return new NotFoundResult();
                }

                return new OkObjectResult(entity);
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"Error retrieving customer with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}