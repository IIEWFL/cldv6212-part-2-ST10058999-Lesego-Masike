using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class GetMessagesFunction
    {
        private readonly QueueStorageService _queueStorageService;

        public GetMessagesFunction(QueueStorageService queueStorageService)
        {
            _queueStorageService = queueStorageService;
        }

        [FunctionName("GetMessages")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "logs")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Processing request to retrieve all log messages");

            try
            {
                var messages = await _queueStorageService.GetMessagesAsync();
                return new OkObjectResult(messages);
            }
            catch (Exception ex)
            {
                log.LogError(ex, "Error retrieving log messages");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}