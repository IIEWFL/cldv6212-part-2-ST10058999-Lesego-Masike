﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class CreateProductFunction
    {
        private readonly TableStorageService _tableStorageService;
        private readonly QueueStorageService _queueStorageService;

        public CreateProductFunction(TableStorageService tableStorageService, QueueStorageService queueStorageService)
        {
            _tableStorageService = tableStorageService;
            _queueStorageService = queueStorageService;
        }

        [FunctionName("CreateProduct")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "products")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Processing request to create a new product");

            try
            {
                var form = await req.ReadFormAsync();
                var partitionKey = "Product";
                var rowKey = Guid.NewGuid().ToString();
                var product = new { PartitionKey = partitionKey, RowKey = rowKey, Name = form["name"], Price = form["price"], Description = form["description"] };

                if (string.IsNullOrEmpty(product.Name) || string.IsNullOrEmpty(product.Price))
                {
                    log.LogWarning("Missing required product fields");
                    return new BadRequestObjectResult("Name and Price are required");
                }

                await _tableStorageService.AddEntityAsync(product);
                await _queueStorageService.SendMessagesAsync(new { Action = "Create", Entity = product });
                log.LogInformation($"Created product with PartitionKey: {partitionKey}, RowKey: {rowKey}");

                return new OkObjectResult(product);
            }
            catch (Exception ex)
            {
                log.LogError(ex, "Error creating product");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}