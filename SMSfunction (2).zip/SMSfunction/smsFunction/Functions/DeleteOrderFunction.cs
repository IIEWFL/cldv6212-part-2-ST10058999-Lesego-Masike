﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using smsFunction.Services;

namespace smsFunction.Functions
{
    public class DeleteOrderFunction
    {
        private readonly TableStorageService _tableStorageService;
        private readonly QueueStorageService _queueStorageService;

        public DeleteOrderFunction(TableStorageService tableStorageService, QueueStorageService queueStorageService)
        {
            _tableStorageService = tableStorageService;
            _queueStorageService = queueStorageService;
        }

        [FunctionName("DeleteOrder")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "delete", Route = "orders/{partitionKey}/{rowKey}")] HttpRequest req,
            string partitionKey, string rowKey,
            ILogger log)
        {
            log.LogInformation($"Processing request to delete order with PartitionKey: {partitionKey}, RowKey: {rowKey}");

            try
            {
                var entity = await _tableStorageService.GetEntityAsync(partitionKey, rowKey);
                if (entity == null)
                {
                    log.LogWarning($"Order not found with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                    return new NotFoundResult();
                }

                await _tableStorageService.DeleteEntityAsync(partitionKey, rowKey);
                await _queueStorageService.SendMessagesAsync(new { Action = "Delete", Entity = entity });
                log.LogInformation($"Deleted order with PartitionKey: {partitionKey}, RowKey: {rowKey}");

                return new OkResult();
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"Error deleting order with PartitionKey: {partitionKey}, RowKey: {rowKey}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}