﻿using System;
using Azure.Storage.Files.Shares;

namespace smsFunction.Services.Storage
{
    public class FileServiceClient
    {
        internal ShareClient GetShareClient(string shareName)
        {
            throw new NotImplementedException();
        }
    }
}