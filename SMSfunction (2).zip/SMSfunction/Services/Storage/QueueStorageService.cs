﻿using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Queues;

namespace smsFunction.Services.Storage
{
    public class QueueStorageService
    {
        private readonly QueueClient _queueClient;

        public QueueStorageService(QueueServiceClient queueServiceClient, string queueName)
        {
            _queueClient = queueServiceClient.GetQueueClient(queueName);
            _queueClient.CreateIfNotExists();
        }

        public async Task SendMessageAsync(string message)
        {
            var bytes = Encoding.UTF8.GetBytes(message);
            await _queueClient.SendMessageAsync(Convert.ToBase64String(bytes));
        }

        public async Task<string> ReceiveMessageAsync()
        {
            var response = await _queueClient.ReceiveMessageAsync();
            if (response.Value != null)
            {
                await _queueClient.DeleteMessageAsync(response.Value.MessageId, response.Value.PopReceipt);
                return Encoding.UTF8.GetString(Convert.FromBase64String(response.Value.MessageText));
            }
            return null;
        }
    }
}