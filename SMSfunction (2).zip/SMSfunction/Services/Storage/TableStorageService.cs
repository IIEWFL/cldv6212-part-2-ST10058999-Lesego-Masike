﻿using ABCRETAIL.Models;
using Azure.Data.Tables;
using System.Threading.Tasks;

namespace smsFunction.Services.Storage
{
    public class TableStorageService<T> where T : class, ITableEntity, new()
    {
        private readonly TableClient _tableClient;

        public TableStorageService(TableServiceClient tableServiceClient, string tableName)
        {
            _tableClient = tableServiceClient.GetTableClient(tableName);
            _tableClient.CreateIfNotExists();
        }

        public async Task<T> UpsertEntityAsync(T entity)
        {
            await _tableClient.UpsertEntityAsync(entity);
            return entity;
        }

        public async Task<T> GetEntityAsync(string partitionKey, string rowKey)
        {
            var response = await _tableClient.GetEntityAsync<T>(partitionKey, rowKey);
            return response.Value;
        }

        public async Task DeleteEntityAsync(string partitionKey, string rowKey)
        {
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
    }
}