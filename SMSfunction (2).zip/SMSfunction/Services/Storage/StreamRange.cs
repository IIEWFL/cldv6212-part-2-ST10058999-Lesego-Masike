﻿using System.IO;

namespace smsFunction.Services.Storage
{
    internal class StreamRange
    {
        private Stream content;

        public StreamRange(Stream content)
        {
            this.content = content;
        }
    }
}