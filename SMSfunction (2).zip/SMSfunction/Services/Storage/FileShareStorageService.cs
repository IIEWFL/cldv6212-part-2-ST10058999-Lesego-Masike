﻿using Azure.Storage.Files.Shares;
using System.IO;
using System.Threading.Tasks;

namespace smsFunction.Services.Storage
{
    public class FileShareStorageService
    {
        private readonly ShareClient _shareClient;

        public FileShareStorageService(FileServiceClient fileServiceClient, string shareName)
        {
            _shareClient = fileServiceClient.GetShareClient(shareName);
            _shareClient.CreateIfNotExists();
        }

        public async Task<string> UploadFileAsync(string filePath, Stream content)
        {
            var directoryClient = _shareClient.GetDirectoryClient(Path.GetDirectoryName(filePath) ?? "");
            directoryClient.CreateIfNotExists();
            var fileClient = directoryClient.GetFileClient(Path.GetFileName(filePath));
            await fileClient.CreateAsync(content.Length);
            // Upload the content to the file using the correct overload
            await fileClient.UploadRangeAsync(
                new Azure.HttpRange(0, content.Length),
                content
            );
            return fileClient.Uri.ToString();
        }

        public async Task<Stream> DownloadFileAsync(string filePath)
        {
            var directoryClient = _shareClient.GetDirectoryClient(Path.GetDirectoryName(filePath) ?? "");
            var fileClient = directoryClient.GetFileClient(Path.GetFileName(filePath));
            var response = await fileClient.DownloadAsync();
            return response.Value.Content;
        }

        public async Task DeleteFileAsync(string filePath)
        {
            var directoryClient = _shareClient.GetDirectoryClient(Path.GetDirectoryName(filePath) ?? "");
            var fileClient = directoryClient.GetFileClient(Path.GetFileName(filePath));
            await fileClient.DeleteIfExistsAsync();
        }
    }
}