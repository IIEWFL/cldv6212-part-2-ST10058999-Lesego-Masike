﻿using System;
using System.Threading.Tasks;
using ABCRETAIL.Models;
using Azure;
using Azure.Data.Tables;
using smsFunction.Models;

namespace smsFunction.Services
{
    public class CustomerService
    {
        private readonly TableClient _tableClient;

        public CustomerService(TableServiceClient tableServiceClient)
        {
            _tableClient = tableServiceClient.GetTableClient("Customers");
        }

        public async Task<CustomerEntity> CreateCustomerAsync(CustomerDto dto)
        {
            var entity = new CustomerEntity
            {
                PartitionKey = dto.Name ?? "DefaultPartition",
                RowKey = Guid.NewGuid().ToString(),
                Name = dto.Name,
                Email = dto.Email,
                ETag = ETag.All
            };
            await _tableClient.UpsertEntityAsync(entity);
            return entity;
        }

        public async Task<CustomerEntity> GetCustomerAsync(string partitionKey, string rowKey)
        {
            var entity = await _tableClient.GetEntityAsync<CustomerEntity>(partitionKey, rowKey);
            return entity.Value;
        }

        public async Task<CustomerEntity> UpdateCustomerAsync(string partitionKey, string rowKey, CustomerDto dto)
        {
            var entity = await _tableClient.GetEntityAsync<CustomerEntity>(partitionKey, rowKey);
            var updatedEntity = entity.Value;
            updatedEntity.Name = dto.Name ?? updatedEntity.Name;
            updatedEntity.Email = dto.Email ?? updatedEntity.Email;
            await _tableClient.UpsertEntityAsync(updatedEntity, TableUpdateMode.Replace);
            return updatedEntity;
        }

        public async Task DeleteCustomerAsync(string partitionKey, string rowKey)
        {
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
    }
}