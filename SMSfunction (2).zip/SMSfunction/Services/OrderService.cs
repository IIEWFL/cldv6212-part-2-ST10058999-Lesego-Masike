﻿using System;
using System.Threading.Tasks;
using ABCRETAIL.Models;
using Azure;
using Azure.Data.Tables;
using smsFunction.Models;

namespace smsFunction.Services
{
    public class OrderService
    {
        private readonly TableClient _tableClient;

        public OrderService(TableServiceClient tableServiceClient)
        {
            _tableClient = tableServiceClient.GetTableClient("Orders");
        }

        public async Task<OrderEntity> CreateOrderAsync(OrderDto dto)
        {
            var entity = new OrderEntity
            {
                PartitionKey = dto.CustomerId ?? "DefaultPartition",
                RowKey = Guid.NewGuid().ToString(),
                CustomerId = dto.CustomerId,
                ProductId = dto.ProductId,
                Quantity = dto.Quantity,
                ETag = ETag.All
            };
            await _tableClient.UpsertEntityAsync(entity);
            return entity;
        }

        public async Task<OrderEntity> GetOrderAsync(string partitionKey, string rowKey)
        {
            var entity = await _tableClient.GetEntityAsync<OrderEntity>(partitionKey, rowKey);
            return entity.Value;
        }

        public async Task<OrderEntity> UpdateOrderAsync(string partitionKey, string rowKey, OrderDto dto)
        {
            var entity = await _tableClient.GetEntityAsync<OrderEntity>(partitionKey, rowKey);
            var updatedEntity = entity.Value;
            updatedEntity.CustomerId = dto.CustomerId ?? updatedEntity.CustomerId;
            updatedEntity.ProductId = dto.ProductId ?? updatedEntity.ProductId;
            updatedEntity.Quantity = dto.Quantity ?? updatedEntity.Quantity;
            await _tableClient.UpsertEntityAsync(updatedEntity, TableUpdateMode.Replace);
            return updatedEntity;
        }

        public async Task DeleteOrderAsync(string partitionKey, string rowKey)
        {
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
    }
}