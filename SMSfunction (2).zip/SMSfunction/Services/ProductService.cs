﻿using System;
using System.Threading.Tasks;
using ABCRETAIL.Models;
using Azure;
using Azure.Data.Tables;

namespace smsFunction.Services
{
    public class ProductService
    {
        private readonly TableClient _tableClient;

        public ProductService(TableServiceClient tableServiceClient)
        {
            _tableClient = tableServiceClient.GetTableClient("Products");
        }

        public async Task<ProductEntity> CreateProductAsync(ProductDto dto)
        {
            var entity = new ProductEntity
            {
                PartitionKey = dto.Name ?? "DefaultPartition",
                RowKey = Guid.NewGuid().ToString(),
                Name = dto.Name,
                Price = dto.Price,
                Description = dto.Description,
                ETag = ETag.All
            };
            await _tableClient.UpsertEntityAsync(entity);
            return entity;
        }

        public async Task<ProductEntity> GetProductAsync(string partitionKey, string rowKey)
        {
            var entity = await _tableClient.GetEntityAsync<ProductEntity>(partitionKey, rowKey);
            return entity.Value;
        }

        public async Task<ProductEntity> UpdateProductAsync(string partitionKey, string rowKey, ProductDto dto)
        {
            var entity = await _tableClient.GetEntityAsync<ProductEntity>(partitionKey, rowKey);
            var updatedEntity = entity.Value;
            updatedEntity.Name = dto.Name ?? updatedEntity.Name;
            updatedEntity.Price = dto.Price ?? updatedEntity.Price;
            updatedEntity.Description = dto.Description ?? updatedEntity.Description;
            await _tableClient.UpsertEntityAsync(updatedEntity, TableUpdateMode.Replace);
            return updatedEntity;
        }

        public async Task DeleteProductAsync(string partitionKey, string rowKey)
        {
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
    }
}