﻿using ABCRETAIL.Models;
using ABCRETAIL.Services;
using ABCRETAIL.Services.Storage;

namespace ABCRETAIL
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllersWithViews();

            var storageConnectionString = builder.Configuration.GetConnectionString("StorageConnectionString")
                ?? throw new InvalidOperationException("Storage connection string is missing in appsettings.json");

            builder.Services.AddSingleton<TableStorageService<CustomerEntity>>(
                _ => new TableStorageService<CustomerEntity>(storageConnectionString, "Customers"));
            builder.Services.AddSingleton<TableStorageService<ProductEntity>>(
                _ => new TableStorageService<ProductEntity>(storageConnectionString, "Products"));
            builder.Services.AddSingleton<TableStorageService<OrderEntity>>(
                _ => new TableStorageService<OrderEntity>(storageConnectionString, "Orders"));
            builder.Services.AddSingleton<TableStorageService<AuditLogEntity>>(
                _ => new TableStorageService<AuditLogEntity>(storageConnectionString, "AuditLogs"));

            builder.Services.AddScoped<CustomerService>(sp =>
                new CustomerService(sp.GetRequiredService<TableStorageService<CustomerEntity>>()));
            builder.Services.AddScoped<ProductService>(sp =>
                new ProductService(sp.GetRequiredService<TableStorageService<ProductEntity>>()));
            builder.Services.AddScoped<OrderService>(sp =>
                new OrderService(sp.GetRequiredService<TableStorageService<OrderEntity>>()));

            builder.Services.AddSingleton<BlobStorageService>(sp =>
            {
                string containerName = "product-images";
                return new BlobStorageService(storageConnectionString, containerName);
            });

            builder.Services.AddSingleton<QueueStorageService>(sp =>
            {
                string queueName = "auditlog";
                return new QueueStorageService(storageConnectionString, queueName);
            });

            builder.Services.AddSingleton<FileShareStorageService>(sp =>
            {
                string shareName = "audit-exports";
                return new FileShareStorageService(storageConnectionString, shareName);
            });

            var app = builder.Build();

            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}