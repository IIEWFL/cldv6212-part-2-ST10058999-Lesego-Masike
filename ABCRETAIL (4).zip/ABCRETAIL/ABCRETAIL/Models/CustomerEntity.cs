﻿// Models/CustomerEntity.cs
using Azure;
using Azure.Data.Tables;

namespace ABCRETAIL.Models
{
    public class CustomerEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "CUSTOMER";
        public string RowKey { get; set; } = Guid.NewGuid().ToString(); // CustomerId
        public string Id => RowKey;

        public string CustomerName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;

        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
    }
}
