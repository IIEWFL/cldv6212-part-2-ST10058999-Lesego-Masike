﻿using Azure;
using Azure.Data.Tables;

namespace ABCRETAIL.Models
{
    public class AuditLogEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = string.Empty; // Initialized to avoid CS8618
        public string RowKey { get; set; } = string.Empty;      // Initialized to avoid CS8618
        public string LogData { get; set; } = string.Empty;
        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
    }
}