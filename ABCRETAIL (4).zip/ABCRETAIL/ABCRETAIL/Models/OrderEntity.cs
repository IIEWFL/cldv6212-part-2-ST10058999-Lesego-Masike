﻿// Models/OrderEntity.cs
using Azure;
using Azure.Data.Tables;

namespace ABCRETAIL.Models
{
    public class OrderEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "ORDER";
        public string RowKey { get; set; } = Guid.NewGuid().ToString(); // OrderId
        public string OrderId => RowKey;

        public string CustomerId { get; set; } = string.Empty;
        public string ProductId { get; set; } = string.Empty;
        public int Quantity { get; set; }

        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
    }
}
